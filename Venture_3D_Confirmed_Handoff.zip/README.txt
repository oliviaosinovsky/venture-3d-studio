VENTURE 3D — CONFIRMED HANDOFF

Carry this entire ZIP into Mission 3. model.glb contains the geometry and embedded textures. Load it with Three.js GLTFLoader. Units: meters; Y is up. Use the camera, lighting and background from model-manifest.json. project.json is the editable backup and includes image assets. Import it into Venture 3D Studio to continue editing.

Schema 1.0: dimensions are world-space axis-aligned bounds; camera position and target are XYZ meters. sha256 is the lowercase SHA-256 of model.glb. All filenames are relative to this ZIP. Confirmation is a snapshot, not a website publication. This model is a stylized concept prototype, not a manufacturing specification.